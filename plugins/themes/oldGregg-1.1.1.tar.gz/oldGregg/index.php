<?php

/**
 * @file plugins/themes/oldGregg/index.php
 *
 * Copyright (c) 2017 Vitaliy Bezsheiko, MD
 *
 *
 */

require_once('OldGreggThemePlugin.inc.php');

return new OldGreggThemePlugin();

?>
