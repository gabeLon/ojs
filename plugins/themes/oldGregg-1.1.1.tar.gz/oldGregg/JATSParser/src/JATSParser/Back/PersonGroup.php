<?php namespace JATSParser\Back;

interface PersonGroup {

	public function getType();

}
