<?php namespace JATSParser\Body;

interface JATSElement {

	public function getContent();

}