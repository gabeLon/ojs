<?php namespace JATSParser\HTML;


interface HTMLElement {

}